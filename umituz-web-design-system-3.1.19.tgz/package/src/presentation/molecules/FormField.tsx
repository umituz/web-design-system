/**
 * FormField Component (Molecule)
 * @description Label + Input combination (Responsive)
 */

import { forwardRef } from 'react';
import { cn, getSpaceY } from '../../infrastructure/utils';
import type { BaseProps } from '../../domain/types';
import { Input } from '../atoms/Input';
import { Text } from '../atoms/Text';

export interface FormFieldProps extends BaseProps {
  label?: string;
  error?: string;
  helperText?: string;
  required?: boolean;
  id?: string;
  inputProps?: React.ComponentProps<typeof Input>;
  fullWidth?: boolean; // Enable responsive full width
}

export const FormField = forwardRef<HTMLInputElement, FormFieldProps>(
  ({ label, error, helperText, required, id, className, inputProps, fullWidth = true, ...props }, ref) => {
    const fieldId = id || inputProps?.id || inputProps?.name;
    const errorId = error ? `${fieldId}-error` : undefined;
    const helperId = helperText ? `${fieldId}-helper` : undefined;

    return (
      <div className={cn(getSpaceY('sm'), fullWidth && 'w-full', className)} {...props}>
        {label && (
          <label htmlFor={fieldId} className="text-sm font-medium block">
            {label}
            {required && <span className="text-destructive ml-1" aria-label="required">*</span>}
          </label>
        )}

        <Input
          ref={ref}
          id={fieldId}
          aria-invalid={!!error}
          aria-describedby={cn(errorId, helperId)}
          error={!!error}
          {...inputProps}
        />

        {error && (
          <Text as="p" variant="caption" size="sm" id={errorId} className="text-destructive">
            {error}
          </Text>
        )}

        {helperText && !error && (
          <Text as="p" variant="caption" size="sm" id={helperId} className="text-muted-foreground">
            {helperText}
          </Text>
        )}
      </div>
    );
  }
);

FormField.displayName = 'FormField';
